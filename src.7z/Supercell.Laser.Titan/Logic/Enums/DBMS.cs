﻿namespace Supercell.Laser.Titan.Logic.Enums
{
    public enum DBMS
    {
        Mongo = 0,
        File  = 1
    }
}