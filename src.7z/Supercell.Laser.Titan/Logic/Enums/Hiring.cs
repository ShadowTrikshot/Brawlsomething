﻿namespace Supercell.Laser.Titan.Logic.Enums
{
    public enum Hiring
    {
        Open    = 0,
        Closed  = 1,
        Invite  = 2
    }
}