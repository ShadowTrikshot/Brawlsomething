﻿namespace Supercell.Laser.Titan.Logic.Enums
{
    public enum Mode
    {
        Production,
        Stage,
        Integration
    }
}