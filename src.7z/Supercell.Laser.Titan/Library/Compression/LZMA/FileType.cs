﻿namespace Supercell.Laser.Titan.Library.Compression.LZMA
{
    public enum FileType
    {
        CSV,
        SC
    }
}
