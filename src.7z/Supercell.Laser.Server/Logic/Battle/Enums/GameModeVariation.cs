﻿namespace Supercell.Laser.Server.Logic.Battle.Enums
{
    internal enum GameModeVariation
    {
        GemGrab,
        Showdown
    }
}
