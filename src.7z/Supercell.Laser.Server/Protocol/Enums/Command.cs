﻿namespace Supercell.Laser.Server.Protocol.Enums
{
    internal enum Command
    {
        ChangeName = 201,
        GiveDeliveryItems = 203
    }
}
