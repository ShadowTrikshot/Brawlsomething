﻿namespace Supercell.Laser.Server.Protocol.Enums
{
    internal enum ServiceNode
    {
        Account = 1,
        Battle = 4,
        Home = 9
    }
}
